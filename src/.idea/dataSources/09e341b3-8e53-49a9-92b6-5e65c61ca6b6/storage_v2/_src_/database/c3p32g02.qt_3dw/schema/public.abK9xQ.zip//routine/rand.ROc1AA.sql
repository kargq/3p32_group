create function rand() returns double precision
as
$$ SELECT random();
$$;

