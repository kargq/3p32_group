create function if(boolean, integer, integer) returns integer
as
$$ SELECT CASE WHEN $1 THEN $2 ELSE $3 END;
$$;

