create function concat(text, text) returns text
as
$$ SELECT $1 || $2;
$$;

