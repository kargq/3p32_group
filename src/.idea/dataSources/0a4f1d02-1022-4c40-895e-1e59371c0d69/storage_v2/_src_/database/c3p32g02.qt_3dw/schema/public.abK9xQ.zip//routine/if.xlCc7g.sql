create function if(boolean, integer, integer) returns integer
    language sql
as
$$
SELECT CASE WHEN $1 THEN $2 ELSE $3 END;
$$;

