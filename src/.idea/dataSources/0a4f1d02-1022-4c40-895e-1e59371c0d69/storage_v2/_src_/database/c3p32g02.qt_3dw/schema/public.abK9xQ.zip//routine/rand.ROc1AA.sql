create function rand() returns double precision
    language sql
as
$$
SELECT random();
$$;

