create function on_delete_clan_member() returns trigger
    language plpgsql
as
$$
BEGIN
    -- check if the memeber being deleted is a clan chief
    IF EXISTS(
            SELECT *
            FROM clan C
            WHERE C.chief = OLD.char_name
              AND C.clanname = OLD.cln_name
        )
    THEN
        raise exception 'Clan member is a chief, appoint new chief before removing.';
    END IF;
    RETURN OLD;
END;
$$;

