create function concat(text, text) returns text
    language sql
as
$$
SELECT $1 || $2;
$$;

