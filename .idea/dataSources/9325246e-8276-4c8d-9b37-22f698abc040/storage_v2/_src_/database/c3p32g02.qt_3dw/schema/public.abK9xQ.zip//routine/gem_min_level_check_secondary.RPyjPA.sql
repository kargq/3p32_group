create function gem_min_level_check_secondary() returns trigger
    language plpgsql
as
$$
BEGIN
    IF EXISTS(
            SELECT *
            FROM Gem G,
                 secondary_equipment_instance I,
                 Equipment E
            WHERE NEW.gem_id = G.gem_id
              AND NEW.secondary_weapon_instance_id = I.secondary_weapon_instance_id
              AND E.eqp_id = I.eqp_id
              AND G.glevel > E.elevel) THEN
        raise
            exception 'Equipment level is too low for equipping the gem';
    END IF;
    IF (SELECT e.gem_limit
        FROM equipment e,
             secondary_equipment_instance ai
        where e.eqp_id = ai.eqp_id
          and ai.secondary_weapon_instance_id = NEW.secondary_weapon_instance_id
        limit 1) <= (SELECT count(*) from secondary_equipment_instance ae where ae.secondary_weapon_instance_id = NEW.secondary_weapon_instance_id)
    then
        raise exception 'Gem limit for secondary equipment instance reached';
    end if;
    RETURN NEW;
END;
$$;

