create function update_levels() returns trigger
    language plpgsql
as
$$
declare
    _cls_name CHAR(20); _base_life INT; _base_power INT; _base_strength INT; _base_will INT; _base_speed INT;
BEGIN
    NEW.char_level := NEW.char_experience / 1000 + 1;

    select * INTO _cls_name, _base_life, _base_power, _base_strength, _base_will, _base_speed
    from class
    where class.cls_name = NEW.has_class
    limit 1;

    IF (lower(NEW.has_class) = 'warrior') THEN
        NEW.char_life := (NEW.char_experience / 1000) * _base_life + 10;
        NEW.char_power := (NEW.char_experience / 1000) * _base_power + 10;
        NEW.char_strength := (NEW.char_experience / 1000) * _base_strength + 10;
        NEW.char_defence := (NEW.char_experience / 1000) * _base_will + 10;
        NEW.char_will := (NEW.char_experience / 1000) * _base_life + 10;
        NEW.char_speed := (NEW.char_experience / 1000) * _base_speed + 10;
    END IF;

    RETURN NEW;
END;
$$;

