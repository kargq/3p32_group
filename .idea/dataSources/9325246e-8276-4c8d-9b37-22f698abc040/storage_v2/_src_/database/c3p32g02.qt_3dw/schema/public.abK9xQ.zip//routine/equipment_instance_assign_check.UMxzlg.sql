create function equipment_instance_assign_check() returns trigger
    language plpgsql
as
$$
BEGIN
    -- all we need from the row is the Character name and equipment instance id
    -- only need to check if min level of equipment is less than char level
    -- so we're just enforcing the character level against the equipment level here.
    IF EXISTS(
            SELECT *
            FROM Character C,
                 Equipment E
            WHERE C.char_name = NEW.char_name
              AND (E.eqp_id = NEW.armour_equipped
                OR E.eqp_id = NEW.main_equipped
                OR E.eqp_id = NEW.secondary_equipped)
              AND C.char_level < E.elevel) THEN
        raise
            exception 'Character level is too low for given equipment';
    END IF;
    RETURN NEW;
END;
$$;

