create function check_earned_skill_in_auto() returns trigger
    language plpgsql
as
$$
BEGIN
    -- check if earned skill is in auto (with given classname) and if it is, don't add it
    IF EXISTS(
            SELECT *
            FROM Auto_Skill A
            WHERE A.skill_id = NEW.skill_id
              AND A.cls_name = NEW.cls_name) THEN
        raise
            exception 'Skill is already an auto skill and cannot be listed as an earned skill';
    END IF;
    RETURN NEW;
END;
$$;

