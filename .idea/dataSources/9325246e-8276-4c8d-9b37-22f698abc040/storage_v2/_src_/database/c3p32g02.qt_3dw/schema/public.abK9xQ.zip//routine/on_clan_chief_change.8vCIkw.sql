create function on_clan_chief_change() returns trigger
    language plpgsql
as
$$
BEGIN
    -- insert chief into clan_member as well
    -- need check before inserting otherwise it just throws an error and exits
    IF NOT EXISTS(
            SELECT *
            FROM clan_member C
            WHERE C.char_name = NEW.chief
              AND C.cln_name = new.clanname
        )
    THEN
        INSERT INTO clan_member
        VALUES (NEW.clanname, NEW.chief);
    END IF;
    RETURN NEW;
END;
$$;

