create function check_auto_skill_in_earned() returns trigger
    language plpgsql
as
$$
BEGIN
    -- check if earned skill is in auto (with given classname) and if it is, don't add it
    IF EXISTS(
            SELECT *
            FROM Earned_Skill A
            WHERE A.skill_id = NEW.skill_id
              AND A.cls_name = NEW.cls_name) THEN
        raise
            exception 'Skill is already an earned skill and cannot be listed as an auto skill';
    END IF;
    RETURN NEW;
END;
$$;

