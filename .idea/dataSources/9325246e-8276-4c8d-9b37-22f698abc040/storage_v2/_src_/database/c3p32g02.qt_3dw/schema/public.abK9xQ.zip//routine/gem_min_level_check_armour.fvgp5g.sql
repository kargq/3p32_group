create function gem_min_level_check_armour() returns trigger
    language plpgsql
as
$$
BEGIN
    -- really just need values of gem Id
    -- check will be when a row is added in any of the embed tables.
    IF EXISTS(
            SELECT *
            FROM Gem G,
                 Armour_instance AI,
                 Equipment E
            WHERE NEW.gem_id = G.gem_id
              AND NEW.armour_instance_id = AI.armour_instance_id
              AND E.eqp_id = AI.eqp_id
              AND G.glevel > E.elevel) THEN
        raise
            exception 'Equipment level is too low for equipping the gem';
    END IF;
    IF (SELECT e.gem_limit
        FROM equipment e,
             armour_instance ai
        where e.eqp_id = ai.eqp_id
          and ai.armour_instance_id = NEW.armour_instance_id
        limit 1) <= (SELECT count(*) from armour_embed ae where ae.armour_instance_id = NEW.armour_instance_id)
    then
        raise exception 'Gem limit for armour instance reached';
    end if;
    RETURN NEW;
END;
$$;

