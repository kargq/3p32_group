create function gem_min_level_check_main() returns trigger
    language plpgsql
as
$$
BEGIN
    IF EXISTS(
            SELECT *
            FROM Gem G,
                 main_weapon_instance I,
                 Equipment E
            WHERE NEW.gem_id = G.gem_id
              AND NEW.main_weapon_instance_id = I.main_weapon_instance_id
              AND E.eqp_id = I.eqp_id
              AND G.glevel > E.elevel) THEN
        raise
            exception 'Equipment level is too low for equipping the gem';
    END IF;
    IF (SELECT e.gem_limit
        FROM equipment e,
             main_weapon_instance ai
        where e.eqp_id = ai.eqp_id
          and ai.main_weapon_instance_id = NEW.main_weapon_instance_id
        limit 1) <= (SELECT count(*) from main_weapon_instance ae where ae.main_weapon_instance_id = NEW.main_weapon_instance_id)
    then
        raise exception 'Gem limit for main weapon instance reached';
    end if;
    RETURN NEW;
END;
$$;

