create function skill_min_level_check() returns trigger
    language plpgsql
as
$$
BEGIN
    -- row will have skill_id and char_name, need to make checks according to that
    -- check if skill is already assigned through auto skills, and if so, do not assign it.
    -- need to check if the skill belongs to the Characters class and is in the earned skills table.
    IF NOT EXISTS(
            SELECT *
            FROM Earned_Skill ES,
                 Character CH,
                 Skill S
            WHERE
              -- find if there is such a skill in the earned skills table, if not, throw an exception.
                CH.char_name = NEW.char_name
              AND ES.skill_id = NEW.skill_id
              AND ES.cls_name = CH.has_class
              AND S.skill_id = ES.skill_id) THEN
        raise
            exception 'This character class is not allowed to access this skill.';
    END IF;
    -- need to check min level.
    IF NOT EXISTS(
            SELECT *
            FROM Earned_Skill ES,
                 Character CH,
                 Skill S
                 -- check if skill_id exists in all skills associated with Character classname
                 -- check if char level is greater than skill level
                 -- finds the earned skill, checks if min level is less than char's level, in that case this query will return not empty.
                 -- i.e. not exists evaluates to false. Otherwise, exception is thrown.
            WHERE CH.char_name = NEW.char_name
              AND ES.skill_id = NEW.skill_id
              AND ES.cls_name = CH.has_class
              AND S.skill_id = ES.skill_id
              AND S.min_level <= CH.char_level) THEN
        raise
            exception 'Invalid skill assignment, check min level for skill';
    END IF;
    RETURN NEW;
END;
$$;

